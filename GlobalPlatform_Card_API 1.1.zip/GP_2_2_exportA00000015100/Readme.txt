March 24, 2006

New export file is generated with GlobalPlatform AID i.e.
0xA0:0x00:0x00:0x01:051:0x00
Version 1.1
used -exportmap with org.globalplatform export file version 1.0 
Used my own environment to generate .exp and .jca file:

java_card_kit-2_2_1
j2sdk1.4.1_02

