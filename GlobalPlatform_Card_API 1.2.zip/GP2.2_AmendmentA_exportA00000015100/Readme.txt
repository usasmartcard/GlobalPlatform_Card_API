January 16, 2009

New export file is generated with GlobalPlatform AID i.e.
0xA0:0x00:0x00:0x01:051:0x00
Version 1.2
used -exportmap with org.globalplatform export file version 1.1 
Used my own environment to generate .exp:

java_card_kit-2_2_1
j2sdk1.4.1_02

