March, 2010

Export file for package 'org.globalplatform' is generated with
 AID: 0xA0:0x00:0x00:0x01:051:0x00
 Version: 1.4
 Backward Compatibility: Version 1.3

Export file for package 'org.globalplatform.contactless' is generated with
 AID: 0xA0:0x00:0x00:0x01:051:0x02
 Version: 1.0
 Backward Compatibility: N/A
